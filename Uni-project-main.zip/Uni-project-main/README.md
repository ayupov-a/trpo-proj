# Uni-project
Here contains all the files of our project
I use DMBS MySQL, technology stack: sql, php, python
